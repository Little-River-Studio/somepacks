#define TRANS_TT
#include "sbgemm_small_kernel_template_cooperlake.c"
