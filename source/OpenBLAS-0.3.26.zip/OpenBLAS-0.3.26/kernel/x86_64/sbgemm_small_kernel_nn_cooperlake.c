#define TRANS_NN
#include "sbgemm_small_kernel_template_cooperlake.c"
